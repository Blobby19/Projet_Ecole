#!/bin/bash

export PS1='$(whoami)@$(hostname):$(pwd)-->'
